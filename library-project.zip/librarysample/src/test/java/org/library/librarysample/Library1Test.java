package org.library.librarysample;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class Library1Test {
	private Library1 library;
	
	//Setting the test environment before each test
	@Before
	public void setUp() {
		library=new Library1();
	}
	
	//tests the add books
	@Test
	public void testAddBook() {
		Book book1=new Book("Data Communications","Behrouz","1003N","GHJ",2007,"CSE",true);
		Book book2=new Book("Network Theory and Filter Design","Vasudev K Aatre","1005N","FGH",1982,"EEE",true);
		
		assertTrue(library.addBook(book1));
		assertFalse(library.addBook(book1));
		assertTrue(library.addBook(book2));
	}
	
	//tests the removing of book by ISBN
	@Test 
	public void testRemoveBook() {
		Book book1=new Book("Data Communications","Behrouz","1003N","GHJ",2007,"CSE",true);
		library.addBook(book1);
		assertTrue(library.removeBook("1003N"));
		assertFalse(library.removeBook("1004N"));
		
	}
	
	//tests the book by author name
	@Test
	public void  testFindByBookAuthor() {
		Book book1=new Book("Data Communications","Behrouz","1003N","GHJ",2007,"CSE",true);
		Book book2=new Book("Network Theory and Filter Design","Vasudev K Aatre","1005N","FGH",1982,"EEE",true);
		library.addBook(book1);
		library.addBook(book2);
		
		List<Book> bookAuthor=library.findBookByAuthor("Behrouz");
		assertEquals(2,bookAuthor.size());
		assertEquals("Behrouz",bookAuthor.get(0).getAuthor());	
		
	}
	
	//test the book by title
	@Test
	public void testFindByBookTitle() {
		Book book1=new Book("Data Communications","Behrouz","1003N","GHJ",2007,"CSE",true);
		Book book2=new Book("Network Theory and Filter Design","Vasudev K Aatre","1005N","FGH",1982,"EEE",true);
		library.addBook(book1);
		library.addBook(book2);
		List<Book> bookTitle=library.findBookByTitle("Data Communications");
		assertEquals(2,bookTitle.size());
		assertEquals("Behrouz",bookTitle.get(0).getTitle());	
		
	}
	
	//test to find all books
	@Test
	public void testFindAllBooks() {
		Book book1=new Book("Data Communications","Behrouz","1003N","GHJ",2007,"CSE",true);
		Book book2=new Book("Network Theory and Filter Design","Vasudev K Aatre","1005N","FGH",1982,"EEE",true);
		library.addBook(book1);
		library.addBook(book2);
		List<Book> books=library.listAllBooks();
		assertEquals(2,books.size());
		
	}
	
	// test to find all available books
	@Test
	public void testFindAllAvailableBooks() {
		Book book1=new Book("Data Communications","Behrouz","1003N","GHJ",2007,"CSE",true);
		Book book2=new Book("Network Theory and Filter Design","Vasudev K Aatre","1005N","FGH",1982,"EEE",false);
		library.addBook(book1);
		library.addBook(book2);
		List<Book> books=library.listAvailableBooks();
		assertEquals(1,books.size());
		
	}
	
	
	
	
	
	

}
