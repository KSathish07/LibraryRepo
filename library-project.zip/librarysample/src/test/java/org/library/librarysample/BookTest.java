package org.library.librarysample;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class BookTest {
	private Book book;
	
	//Setting the test environment before each test
	@Before
	public void setUp() {
		book=new Book("Data Communications","Behrouz","1003N","GHJ",2007,"CSE",true);
		
	}
	//Testing the book by title
	@Test
	public void getTitle() {
		assertEquals("Data Communications",book.getTitle());
		
	}
	//test to set the title of book
	@Test
	public void setTitle() {
		book.setTitle("Data Structures");
		assertEquals("Data Structures",book.getTitle());
	}
	// test the book by author
	@Test
	public void getAuthor() {
		assertEquals("Behrouz",book.getAuthor());
	}
	// test case to set the author of a book
	@Test
	public void setAuthor() {
		book.setAuthor("Narasimha");
		assertEquals("Narasimha",book.getAuthor());
	}
	
	//test method of getting a book by ISBN
	@Test
	public void getIsbn() {
		assertEquals("1003N",book.getIsbn());
	}
	// test method to set a book by ISBN
	@Test
	public void setIsbn() {
		book.setIsbn("1004N");
		assertEquals("1003N",book.getIsbn());
	}
	
	// test by Genre
	@Test
	public void getGenre() {
		assertEquals("GHJ",book.getGenre());
	}
	
	// test to set Genre
	@Test
	public void setGenre() {
		book.setGenre("FGH");
		assertEquals("FGH",book.getGenre());
	}
	
	//test method to get a book by publication year
	@Test
	public void getPublicationYear() {
		Integer expectedYear = 2007;
		assertEquals(expectedYear,book.getPublicationYear());
	}
	
	//test method to set publication year
	@Test
	public void setPublicationYear() {
		book.setPublicationYear(2011);
		Integer expectedYear = 2011;
		assertEquals(expectedYear,book.getPublicationYear());
		
	}
	
	//test method to get a book by department
	@Test
	public void getDepartment() {
		assertEquals("CSE",book.getDepartment());
	}
	
	//test method to set department
	@Test
	public void setDepartment() {
		book.setDepartment("IT");
		assertEquals("CSE",book.getDepartment());
	}
	
	//test method to check the book availability
	@Test
	public void isAvailability() {
		assertEquals(true,book.isAvailability());
	}
	
	
	//test method to set the book availability
	@Test
	public void setAvailability() {
		book.setAvailability(false);
		assertEquals(true,book.isAvailability());
	}
	
	
	
	
	

}
