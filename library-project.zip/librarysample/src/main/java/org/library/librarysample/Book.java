package org.library.librarysample;

public class Book {
	private String title;
	private String author;
	private String isbn;
	private String genre; 
	private Integer publicationYear;
	private String department;
	boolean availability;
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Book(String title, String author, String isbn, String genre, Integer publicationYear,
			String department, boolean availability) {
		super();
		this.title = title;
		this.author = author;
		this.isbn = isbn;
		this.genre = genre;
		this.publicationYear = publicationYear;
		this.department = department;
		this.availability = availability;
	}

	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public Integer getPublicationYear() {
		return publicationYear;
	}
	public void setPublicationYear(Integer publicationYear) {
		this.publicationYear = publicationYear;
	}
	
	
	
	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	 public boolean isAvailability() {
	        return availability;
	    }
	public void setAvailability(Boolean availability) {
		this.availability = availability;
	}

	@Override
	public String toString() {
		return "Book [title=" + title + ", author=" + author + ", isbn=" + isbn + ", genre=" + genre
				+ ", publicationYear=" + publicationYear + ", department=" + department + ", availability="
				+ availability + "]";
	}



}

