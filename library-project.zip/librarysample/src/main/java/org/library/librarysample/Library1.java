package org.library.librarysample;

import java.util.*;
import java.util.stream.Collectors;

public class Library1 {
	private Map<String,List<Book>> departments;
	
	public Library1() {
		this.departments=new HashMap<>();
	}
	// adding books 
	 public boolean addBook(Book book) {
	        if (isDuplicate(book.getIsbn())) {
	            return false;
	        }

	        List<Book> departmentBooks = departments.getOrDefault(book.getDepartment(), new ArrayList<>());
	        departmentBooks.add(book);
	        departments.put(book.getDepartment(), departmentBooks);
	        return true;
	    }
	 //checking the duplicate isbn
	 private boolean isDuplicate(String isbn) {
	        for (List<Book> books : departments.values()) {
	            for (Book book : books) {
	                if (book.getIsbn().equals(isbn)) {
	                    return true;
	                }
	            }
	        }
	        return false;
	    }
	 
	// Remove a book by roll isbn
	    public boolean removeBook(String isbn) {
	        for (List<Book> books : departments.values()) {
	            for (Book book : books) {
	                if (book.getIsbn().equals(isbn)) {
	                    books.remove(book);
	                    return true;
	                }
	            }
	        }
	        return false;
	    }
	    
	 // Find books by title 
	    public List<Book> findBookByTitle(String title) {
	        List<Book> result = new ArrayList<>();
	        for (List<Book> books : departments.values()) {
	            result.addAll(books.stream()
	                    .filter(book -> book.getTitle().equalsIgnoreCase(title))
	                    .collect(Collectors.toList()));
	        }
	        return result;
	    }
	    
	 // Find books by author 
	    public List<Book> findBookByAuthor(String author) {
	        List<Book> result = new ArrayList<>();
	        for (List<Book> books : departments.values()) {
	            result.addAll(books.stream()
	                    .filter(book -> book.getAuthor().equalsIgnoreCase(author))
	                    .collect(Collectors.toList()));
	        }
	        return result;
	    }
	 // Find book list 
	    public List<Book> listAllBooks() {
	        List<Book> result = new ArrayList<>();
	        for (List<Book> books : departments.values()) {
	            result.addAll(books);
	        }
	        return result;
	    }
	 // Find available book list
	    public List<Book> listAvailableBooks() {
	        List<Book> result = new ArrayList<>();
	        for (List<Book> books : departments.values()) {
	            result.addAll(books.stream()
	                    .filter(Book::isAvailability)
	                    .collect(Collectors.toList()));
	        }
	        return result;
	    }

		@Override
		public String toString() {
			return "Library1 [departments=" + departments + "]";
		}
	
	
}

