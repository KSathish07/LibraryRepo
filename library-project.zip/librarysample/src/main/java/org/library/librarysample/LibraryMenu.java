package org.library.librarysample;

import java.util.List;
import java.util.Scanner;



public class LibraryMenu {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Library1 library=new Library1();
		Scanner scanner = new Scanner(System.in);
		
		while(true) {
			System.out.println("1. Add Book");
            System.out.println("2. Remove Book by an ISBN");
            System.out.println("3. Find Book by Title");
            System.out.println("4. Find Book by Author Name");
            System.out.println("5. List All Books");
            System.out.println("6. List Available Books");
            System.out.println("7. Exit the Program");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            
            switch (choice) {
            
            case 1:
            	System.out.print("Enter Book title");
            	String title=scanner.nextLine();
            	
            	System.out.print("Enter Book author");
            	String author=scanner.nextLine();
            	
            	System.out.print("Enter Book ISBN");
            	String isbn=scanner.nextLine();
            	
            	System.out.print("Enter Book genre");
            	String genre=scanner.nextLine();
            	
            	System.out.print("Enter Book publicationYear");
            	Integer publicationYear=scanner.nextInt();
            	
            	
            	System.out.print("Enter Book department");
            	String department=scanner.nextLine();
            	
            	
            	System.out.print("Enter Availability (true/false): ");
                boolean availability = scanner.nextBoolean();
                
                Book book = new Book(title,author,isbn,genre,publicationYear,department,availability);
                if (library.addBook(book)) {
                    System.out.println("Book added successfully.");
                } else {
                    System.out.println("Book with this isbn already exists.");
                }
                break;
            case 2:
                System.out.print("Enter isbn: ");
                isbn = scanner.nextLine();
                if (library.removeBook(isbn)) {
                    System.out.println("Book removed successfully.");
                } else {
                    System.out.println("Book not found.");
                }
                break;
                
            case 3:
                System.out.print("Enter Boook title: ");
                title = scanner.nextLine();
                List<Book> booksByTitle = library.findBookByTitle(title);
                if (booksByTitle.isEmpty()) {
                    System.out.println("No books found with this title name.");
                } else {
                	booksByTitle.forEach(System.out::println);
                }
                break;
                
            case 4:
                System.out.print("Enter Book Author: ");
                author = scanner.nextLine();
                List<Book> bookByAuthorName = library.findBookByAuthor(author);
                if (bookByAuthorName.isEmpty()) {
                    System.out.println("No books found with this author name.");
                } else {
                	bookByAuthorName.forEach(System.out::println);
                }
                break;
                
            case 5:
                List<Book> allBooks = library.listAllBooks();
                if (allBooks.isEmpty()) {
                    System.out.println("No books found.");
                } else {
                	allBooks.forEach(System.out::println);
                }
                break;
                
                
            case 6:
                List<Book> availableBooks = library.listAvailableBooks();
                if (availableBooks.isEmpty()) {
                    System.out.println("No available books found.");
                } else {
                	availableBooks.forEach(System.out::println);
                }
                break;
              
            case 7:
                System.out.println("Exiting...");
                scanner.close();
                return;
            default:
                System.out.println("Invalid choice. Please try again.");
                break;
            	
            
            
            
           // Book book=new Book()
            }
		}
		

	}


}
